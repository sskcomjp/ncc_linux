﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NnCase.Converter.K210.Converters.Layers
{
    [Flags]
    public enum K210LayerFlags
    {
        None = 0,
        MainMemoryOutput = 1
    }
}
