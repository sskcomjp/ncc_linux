﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NnCase.Converter.Model.Layers
{
    public class Requantize : Layer
    {
        public InputConnector Input { get; }

        public OutputConnector Output { get; }

        public string Name { get; set; }

        public Requantize(ReadOnlySpan<int> dimensions)
        {
            Input = AddInput("input", dimensions);
            Output = AddOutput("output", dimensions);
        }

        protected override void OnPlanning(GraphPlanContext context)
        {
            context.TFOutputs[Output] = context.TFGraph.Identity(context.TFOutputs[Input.Connection.From], Name);
        }
    }
}
