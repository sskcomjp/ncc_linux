#pragma once

namespace nncase
{

}