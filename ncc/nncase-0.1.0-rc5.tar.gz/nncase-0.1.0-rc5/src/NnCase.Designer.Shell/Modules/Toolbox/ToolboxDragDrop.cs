﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NnCase.Designer.Modules.Toolbox
{
    public static class ToolboxDragDrop
    {
        public const string DataFormat = "MnCase.Designer.ToolboxItem";
    }
}
